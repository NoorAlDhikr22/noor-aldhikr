import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:just_audio/just_audio.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(NoorApp(prefs: prefs));
}

const supportedLocales = <Locale>[
  Locale('ar'), Locale('en'), Locale('fr'), Locale('de'),
  Locale('es'), Locale('tr'), Locale('id'), Locale('ur'),
  Locale('ms'), Locale('bn'), Locale('ru'), Locale('zh'),
];

class NoorApp extends StatefulWidget {
  const NoorApp({super.key, required this.prefs});
  final SharedPreferences prefs;

  @override
  State<NoorApp> createState() => _NoorAppState();
}

class _NoorAppState extends State<NoorApp> {
  late Locale locale;
  bool dark = false;

  @override
  void initState() {
    super.initState();
    final code = widget.prefs.getString('locale') ?? 'ar';
    locale = supportedLocales.firstWhere(
      (l) => l.languageCode == code,
      orElse: () => const Locale('ar'),
    );
    dark = widget.prefs.getBool('dark') ?? false;
  }

  Future<void> setLocale(Locale value) async {
    setState(() => locale = value);
    await widget.prefs.setString('locale', value.languageCode);
  }

  Future<void> setDark(bool value) async {
    setState(() => dark = value);
    await widget.prefs.setBool('dark', value);
  }

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF174B3B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نور الذكر | Noor Al-Dhikr',
      locale: locale,
      supportedLocales: supportedLocales,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFF7F6F0),
        useMaterial3: true,
        fontFamily: locale.languageCode == 'ar' ? 'Cairo' : null,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      themeMode: dark ? ThemeMode.dark : ThemeMode.light,
      home: HomeShell(
        prefs: widget.prefs,
        locale: locale,
        onLocaleChanged: setLocale,
        dark: dark,
        onDarkChanged: setDark,
      ),
    );
  }
}

class Copy {
  static const data = {
    'ar': {'home':'الرئيسية','quran':'القرآن','adhkar':'الأذكار','saved':'المحفوظات','more':'المزيد',
      'welcome':'نور الذكر','tagline':'رفيقك في رحلتك إلى الله','daily':'وردك اليومي','read':'ابدأ القراءة',
      'morning':'أذكار الصباح','evening':'أذكار المساء','tasbih':'السبحة','bookmarks':'العلامات المرجعية',
      'continue':'متابعة القراءة','settings':'الإعدادات','language':'اللغة','dark':'الوضع الليلي',
      'offline':'المحتوى الأساسي يعمل دون إنترنت','dedication':'صدقة جارية عن زياد جاد وعائلته وكل مسلم ومسلمة',
      'channels':'تابعنا','youtube':'يوتيوب','tiktok':'تيك توك','audio':'التلاوات','download':'التلاوات تُضاف بعد توفير ملفات مرخصة',
      'empty':'لا توجد علامات محفوظة بعد','save':'حفظ علامة مرجعية','savedOk':'تم حفظ العلامة على جهازك',
      'surah':'الفاتحة','verse':'آية تجريبية للواجهة فقط — يُضاف نص المصحف من مصدر موثوق معتمد قبل النشر',
      'privacy':'بياناتك المحلية لا تغادر جهازك في هذه النسخة.'},
    'en': {'home':'Home','quran':'Quran','adhkar':'Adhkar','saved':'Bookmarks','more':'More',
      'welcome':'Noor Al-Dhikr','tagline':'Your companion on the journey to Allah','daily':'Daily routine','read':'Start reading',
      'morning':'Morning adhkar','evening':'Evening adhkar','tasbih':'Tasbih','bookmarks':'Bookmarks',
      'continue':'Continue reading','settings':'Settings','language':'Language','dark':'Dark mode',
      'offline':'Core content works offline','dedication':'A continuing charity on behalf of Ziad Gad, his family, and all Muslim men and women',
      'channels':'Follow us','youtube':'YouTube','tiktok':'TikTok','audio':'Recitations','download':'Licensed audio files will be added',
      'empty':'No bookmarks yet','save':'Save bookmark','savedOk':'Bookmark saved on this device',
      'surah':'Al-Fatiha','verse':'UI sample only — verified Quran text must be added from an approved source before release',
      'privacy':'In this version, your local data stays on your device.'},
  };

  static String t(String lang, String key) =>
      data[lang]?[key] ?? data['en']?[key] ?? key;
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.prefs, required this.locale,
    required this.onLocaleChanged, required this.dark, required this.onDarkChanged});
  final SharedPreferences prefs;
  final Locale locale;
  final ValueChanged<Locale> onLocaleChanged;
  final bool dark;
  final ValueChanged<bool> onDarkChanged;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final List<String> bookmarks = [];

  String get lang => widget.locale.languageCode;
  String tr(String key) => Copy.t(lang, key);

  @override
  void initState() {
    super.initState();
    bookmarks.addAll(widget.prefs.getStringList('bookmarks') ?? []);
  }

  Future<void> addBookmark(String label) async {
    if (!bookmarks.contains(label)) {
      setState(() => bookmarks.add(label));
      await widget.prefs.setStringList('bookmarks', bookmarks);
    }
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(tr('savedOk'))));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      QuranPage(onSave: () => addBookmark('${tr('surah')} • 1:1')),
      AdhkarPage(),
      BookmarksPage(items: bookmarks, onRemove: (v) async {
        setState(() => bookmarks.remove(v));
        await widget.prefs.setStringList('bookmarks', bookmarks);
      }),
      MorePage(locale: widget.locale, onLocaleChanged: widget.onLocaleChanged,
        dark: widget.dark, onDarkChanged: widget.onDarkChanged),
    ];
    final labels = ['home','quran','adhkar','saved','more'];
    final icons = [Icons.home_rounded, Icons.menu_book_rounded, Icons.favorite_rounded,
      Icons.bookmark_rounded, Icons.apps_rounded];
    return Directionality(
      textDirection: lang == 'ar' || lang == 'ur' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        body: SafeArea(child: pages[index]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: List.generate(labels.length, (i) => NavigationDestination(
            icon: Icon(icons[i]), label: tr(labels[i]))),
        ),
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      Row(children: [
        const CircleAvatar(radius: 25, backgroundColor: Color(0xFF174B3B),
          child: Icon(Icons.nights_stay_rounded, color: Color(0xFFE5C77D))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr('welcome'), style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          Text(tr('tagline'), style: Theme.of(context).textTheme.bodyMedium),
        ])),
        IconButton(onPressed: () => setState(() => index = 4), icon: const Icon(Icons.settings_outlined)),
      ]),
      const SizedBox(height: 22),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(colors: [Color(0xFF123D31), Color(0xFF28705A)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(tr('daily'), style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Text(tr('offline'), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          FilledButton.tonal(onPressed: () => setState(() => index = 1),
            child: Text(tr('read'))),
        ]),
      ),
      const SizedBox(height: 18),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.45,
        children: [
          _tile(Icons.menu_book, tr('quran'), () => setState(() => index = 1)),
          _tile(Icons.wb_twilight, tr('morning'), () => setState(() => index = 2)),
          _tile(Icons.nights_stay, tr('evening'), () => setState(() => index = 2)),
          _tile(Icons.bookmark, tr('bookmarks'), () => setState(() => index = 3)),
        ],
      ),
      const SizedBox(height: 22),
      Center(child: Text(tr('dedication'), textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.bodySmall)),
    ],
  );

  Widget _tile(IconData icon, String title, VoidCallback tap) => Card(
    elevation: 0, child: InkWell(
      borderRadius: BorderRadius.circular(18), onTap: tap,
      child: Padding(padding: const EdgeInsets.all(14),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary, size: 28),
          const SizedBox(height: 8), Text(title, textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        ])),
    ),
  );
}

class QuranPage extends StatelessWidget {
  const QuranPage({super.key, required this.onSave});
  final VoidCallback onSave;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Text(Copy.t(Localizations.localeOf(context).languageCode, 'quran'),
      style: Theme.of(context).textTheme.headlineMedium),
    const SizedBox(height: 16),
    Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      Text(Copy.t(Localizations.localeOf(context).languageCode, 'surah'),
        style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 20),
      Text(Copy.t(Localizations.localeOf(context).languageCode, 'verse'),
        textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, height: 2)),
      const SizedBox(height: 16),
      OutlinedButton.icon(onPressed: onSave, icon: const Icon(Icons.bookmark_add),
        label: Text(Copy.t(Localizations.localeOf(context).languageCode, 'save'))),
    ]))),
    const SizedBox(height: 12),
    const Text('مهم: هذه شاشة تأسيسية وليست مصحفًا مكتملًا. لن نعرض نصًا قرآنيًا تجريبيًا على أنه قرآن.'),
  ]);
}

class AdhkarPage extends StatefulWidget {
  @override
  State<AdhkarPage> createState() => _AdhkarPageState();
}
class _AdhkarPageState extends State<AdhkarPage> {
  int count = 0;
  @override
  Widget build(BuildContext context) {
    final lang = Localizations.localeOf(context).languageCode;
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text(Copy.t(lang, 'adhkar'), style: Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const Icon(Icons.wb_twilight),
        title: Text(Copy.t(lang, 'morning')), subtitle: const Text('سيُضاف المحتوى المحقق والمراجع قبل الإصدار.'))),
      Card(child: ListTile(leading: const Icon(Icons.nights_stay),
        title: Text(Copy.t(lang, 'evening')), subtitle: const Text('سيُضاف المحتوى المحقق والمراجع قبل الإصدار.'))),
      const SizedBox(height: 20),
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
        Text(Copy.t(lang, 'tasbih'), style: Theme.of(context).textTheme.titleLarge),
        Text('$count', style: Theme.of(context).textTheme.displayLarge),
        FilledButton.icon(onPressed: () => setState(() => count++),
          icon: const Icon(Icons.add), label: const Text('تسبيحة')),
        TextButton(onPressed: () => setState(() => count = 0), child: const Text('إعادة التصفير')),
      ]))),
    ]);
  }
}

class BookmarksPage extends StatelessWidget {
  const BookmarksPage({super.key, required this.items, required this.onRemove});
  final List<String> items;
  final ValueChanged<String> onRemove;
  @override
  Widget build(BuildContext context) {
    final lang = Localizations.localeOf(context).languageCode;
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text(Copy.t(lang, 'bookmarks'), style: Theme.of(context).textTheme.headlineMedium),
      if (items.isEmpty) Padding(padding: const EdgeInsets.only(top: 40),
        child: Center(child: Text(Copy.t(lang, 'empty')))),
      ...items.map((item) => Card(child: ListTile(
        leading: const Icon(Icons.bookmark, color: Color(0xFFB58A3A)),
        title: Text(item), trailing: IconButton(icon: const Icon(Icons.delete_outline),
          onPressed: () => onRemove(item))))),
    ]);
  }
}

class MorePage extends StatelessWidget {
  const MorePage({super.key, required this.locale, required this.onLocaleChanged,
    required this.dark, required this.onDarkChanged});
  final Locale locale;
  final ValueChanged<Locale> onLocaleChanged;
  final bool dark;
  final ValueChanged<bool> onDarkChanged;

  @override
  Widget build(BuildContext context) {
    final lang = locale.languageCode;
    String t(String k) => Copy.t(lang, k);
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text(t('more'), style: Theme.of(context).textTheme.headlineMedium),
      const SizedBox(height: 12),
      Card(child: ListTile(title: Text(t('language')), leading: const Icon(Icons.language),
        trailing: DropdownButton<String>(value: lang,
          items: supportedLocales.map((l) => DropdownMenuItem(value: l.languageCode,
            child: Text(_languageName(l.languageCode)))).toList(),
          onChanged: (v) { if (v != null) onLocaleChanged(Locale(v)); }))),
      Card(child: SwitchListTile(title: Text(t('dark')), value: dark,
        onChanged: onDarkChanged, secondary: const Icon(Icons.dark_mode))),
      Card(child: ListTile(leading: const Icon(Icons.headphones), title: Text(t('audio')),
        subtitle: Text(t('download')))),
      Card(child: ListTile(leading: const Icon(Icons.favorite), title: Text(t('channels')),
        subtitle: const Text('YouTube: @nooreldhikr  •  TikTok: @ziadgad_'),
        onTap: () {})),
      Card(child: Padding(padding: const EdgeInsets.all(16),
        child: Text(t('dedication'), textAlign: TextAlign.center))),
      Text(t('privacy'), textAlign: TextAlign.center),
    ]);
  }

  String _languageName(String code) => const {
    'ar':'العربية','en':'English','fr':'Français','de':'Deutsch','es':'Español',
    'tr':'Türkçe','id':'Bahasa Indonesia','ur':'اردو','ms':'Bahasa Melayu',
    'bn':'বাংলা','ru':'Русский','zh':'中文'
  }[code] ?? code;
}
